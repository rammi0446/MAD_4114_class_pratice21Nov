//
//  LoginSignUpViewController.swift
//  FirebaseExamples
//
//  Created by MacStudent on 2018-11-21.
//  Copyright © 2018 room1. All rights reserved.
//

import UIKit
import FirebaseAuth


class LoginSignUpViewController: UIViewController {

    @IBOutlet weak var txtNameLogin: UITextField!
    @IBOutlet weak var txtPasswordLogin: UITextField!
    @IBOutlet weak var txtNameSignUp: UITextField!
    @IBOutlet weak var txtPasswordSignUp: UITextField!
    var data = ""
    
    
    @IBAction func btnLogin(_ sender: Any) {
        let name = txtNameLogin.text!
        let password = txtPasswordLogin.text!
        
        Auth.auth().signIn(withEmail: name, password: password)
        {
            (user, error) in
            
            if (user != nil) {
                // 1. Found a user!
                print("User signed in! ")
                print("User id: \(user?.user.uid)")
                print("Email: \(user?.user.email)")
                 self.data = (user?.user.email)!
                // 2. So send them to screen 2!
                self.performSegue(withIdentifier: "segueA", sender: nil)
            }
            else {
                // 1. A problem occured when looking up  the user
                // - doesn't meet password requirements
                // - user already exists
                print("ERROR!")
                print(error?.localizedDescription)
                
                // 2. Show the error in user interface
               print("error  >>>>>>>> \(error?.localizedDescription)")
            }
        }
    }
    
    
    
    @IBAction func btnSignUp(_ sender: Any) {
        let name = txtNameSignUp.text!
        let password = txtPasswordSignUp.text!
        
        Auth.auth().createUser(withEmail: name, password: password) {
            
            (user, error) in
            
            if (user != nil) {
                // 1. New user created!
                print("Created user: ")
                print("User id: \(user?.user.uid)")
                print("Email: \(user?.user.email)")
                
                //2. @TODO: You decide what you want to do next!
                // - do you want to send them to the next page?
                // - maybe ask them to fill in other forms?
                // - show a tutorial?
              
            }
            else {
                // 1. Error when creating a user
                print("ERROR!")
                print(error?.localizedDescription)
                
                // 2. Show the error in the UI
                  print("error  >>>>>>>> \(error?.localizedDescription)")
                
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        print("going to next page")
        let chatPage = segue.destination as! ChatViewController
        chatPage.username = data
        
    }
   

}
